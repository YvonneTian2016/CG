#!/bin/sh
make -C /Users/sriravic/Downloads/final\ project/build_xcode -f /Users/sriravic/Downloads/final\ project/build_xcode/CMakeScripts/ZERO_CHECK_cmakeRulesBuildPhase.make$CONFIGURATION all

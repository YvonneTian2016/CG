#!/bin/sh
make -C /Users/sriravic/Downloads/final\ project/build_xcode -f /Users/sriravic/Downloads/final\ project/build_xcode/CMakeScripts/ALL_BUILD_cmakeRulesBuildPhase.make$CONFIGURATION all
